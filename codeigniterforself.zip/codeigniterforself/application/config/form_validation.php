<?php 
$config = [
		'add_article_rules' =>[

									[
									'field' => 'title',
									'label' => 'Title',
									'rules' => 'required|alpha_dash'
									],
									[
									'field' => 'body',
								    'label' => 'Body',
								    'rules' => 'required'
									]

								]
];
?>