<?= include('admin_header.php'); ?>

<div class="container">
	<div class="row">
		<div class="col-lg-6 col-lg-offset-6">
			<a href="<?= base_url('admin/store_article'); ?>" class="btn btn-primary pull-right">ADD ARTICLE</a>
		</div>
	</div>
	   <?php if($feedback = $this->session->flashdata('feedback')): ?>
	    <div class="row">
	        <div class="col-lg-6 col-lg-offset-3"> 
	        	<!-- offset le 3ta block khayera ani aune ho k -->
	            <div class="alert alert-danger" role="alert">
	                 <?php echo $feedback; ?>
	            </div>
	        </div>
	    </div>
	  <?php endif; ?>
	<table class="table table-striped table-hovered">
		<thead>
			<th>SN</th>
			<th>Title</th>
			<th>Action</th>
		</thead>
		<tbody>
        <?php $i=1; ?>
		<?php if (count($articles) ): ?>
		 	<?php foreach($articles as $article): ?>
			<tr>
				<td><?php echo $i++ ; ?></td>
				<td>
					<?= $article->title ?>
				</td>
				<td>
				<?= anchor("admin/edit_article/".$article->id,'Edit',['class'=>'btn btn-primary']) ;?>
				<?= anchor("admin/delete_article/".$article->id,'Delete',['class'=>'btn btn-danger']) ;?>				
				</td>
			</tr>
			<?php endforeach; ?>
		<?php else: ?>
			<tr>
				<td colspan="3">
					No records found.
				</td>
			</tr>
		<?php endif; ?>
		</tbody>
	</table>
</div>

<?= include('admin_footer.php'); ?>