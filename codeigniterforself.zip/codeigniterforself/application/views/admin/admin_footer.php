<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/css/bootstrap.min.js'); ?>"></script>
</body>
</html>