<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin panel</title>
   <!--  <?= link_tag('assets/css/bootstrap.min.css'); ?> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>

<body>

<!-- <nav class="navbar navbar-light bg-light"> -->
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="">Admin Panel</a>
        </div>
        <ul class="nav navbar-nav">
           
            <li><a href="<?= base_url('login/logout'); ?>">Logout</a></li>
        </ul>
    </div>
</nav>