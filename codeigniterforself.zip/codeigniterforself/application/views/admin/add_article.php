
<?= include('admin_header.php'); ?>
<div class="container">
<?php echo form_open('Admin/store_article', ['class'=>'form-horizontal']); ?>
<?php echo form_hidden('user_id',$this->session->userdata('user_id')); ?>
  <fieldset>
    <legend>Add article here</legend>     
    <div class="form-group">
	<label>Title</label>

		<div class="row">
	    	<div class="col-lg-6">
	    		<?php echo form_input(['name'=>'title','class'=>'form-control','value'=>set_value('title')]); ?> 
	         </div>
	    	<div class="col-lg-6">
	    	<?= form_error('title');?>
	    	</div>
	    </div>	
	</div>
    <div class="form-group">
		<label>Body</label>
		    <div class="row">
    	 		<div class="col-lg-6">  
                 <?php echo form_textarea(['name'=>'body','class'=>'form-control','placeholder'=>'Write anything here','value'=>set_value('body')]); ?>
    		    </div>
    	
    			<div class="col-lg-6">
    		    <?= form_error('body'); ?>
    	        </div>
    	    </div>
    </div>
   
    </fieldset>
    <button type="reset" class="btn btn-default">Reset</button>
    <button type="submit" class="btn btn-primary">Submit</button>
  </fieldset>
</form>
</div>
<?= include_once('admin_footer.php'); ?>
