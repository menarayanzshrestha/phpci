<!DOCTYPE html>
<html>
<head>
	<title>Message page</title>
</head>
<body>

<?php  echo message; ?>
here is message_pgae

</body>
</html>