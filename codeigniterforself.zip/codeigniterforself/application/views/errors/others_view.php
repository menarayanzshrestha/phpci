<!DOCTYPE html>
<html>
<head>
	<title>others view</title>
</head>
<body>
others view
</body>
</html>