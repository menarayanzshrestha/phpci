<?php include('public_header.php'); ?>
<div class="container">
<?php echo form_open('login/admin_login', ['class'=>'form-horizontal']); ?>
  <fieldset>
    <legend>Admin Login</legend>
    <?php if($error= $this->session->flashdata('login_failed')): ?>
        <div class="row">
            <div class="col-lg-6">
                <div class="alert alert-danger" role="alert">
                     <?php echo $error; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
         
    
    <div class="form-group">
	<label>Username</label>
		<div class="row">
	    	<div class="col-lg-6">
	    		<?php echo form_input(['name'=>'Username','class'=>'form-control','placeholder'=>'Enter Username','value'=>set_value('Username')]); ?> 
	         </div>
	    	<div class="col-lg-6">
	    	<?php echo form_error('Username'); ?>
	    	</div>
	    </div>	
	</div>

    <div class="form-group">
		<label for="exampleInputPassword1">Password</label>
		    <div class="row">
    	 		<div class="col-lg-6">  
		        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="Password">
    		    </div>
    	
    			<div class="col-lg-6">
    		    <?php echo form_error('Password'); ?>
    	        </div>
    	    </div>
    </div>
   
    </fieldset>
    <button type="reset" class="btn btn-default">Reset</button>
    <button type="submit" class="btn btn-primary">Submit</button>
  </fieldset>
</form>

</div>


<?php include('public_footer.php'); ?>

