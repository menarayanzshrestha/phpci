<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>articles</title>
    <?= link_tag('assets/css/bootstrap.min.css'); ?>
</head>
<body>

<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand">Navbar</a>
  <form class="form-inline">
    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    <a href="">Login</a> 
  </form>
  
</nav>