<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Loginmodel extends CI_Model {

    private $_tableName = 'users';

    public function loginvalid($username, $password)
    {
        $query = $this->db->get_where($this->_tableName, array('uname' => $username,'pword' => $password));
         if ($query->num_rows()) {
            return $query->row()->id;
        } else {
            return FALSE; 
        }
    }

    public function save($data)
    {
        $query = $this->db->insert($this->_tableName, $data);
        if ($query) {
            return $query;
        } else {
            return FALSE;
        }
    }
    public function update($id, $data)
    {
        $query = $this->db->update($this->_tableName, $data, array('id' => $id));
        if ($query) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
    public function updateByUser($username, $data)
    {
        $query = $this->db->update($this->_tableName, $data, array('username' => $username));
        if ($query) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
    public function getAll()
    {
        $query = $this->db->get($this->_tableName);
        if ($query->num_rows() >= 1) {
            return $query->result_array();
        } else {
            return FALSE;
        }
    }
    public function getById($id)
    {
        $query = $this->db->get_where($this->_tableName, array('id' => $id));
        if ($query->num_rows() == 1) {
            return $query->row_array();
        } else {
            return FALSE;
        }
    }
}

?>