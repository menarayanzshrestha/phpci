<?php 
class Articlesmodel extends CI_model {
	
	private $_tableName = "articles";

	 public function articles_list() 
	{
	 	 $user_id = $this->session->userdata('user_id');
	 	 //print_r($user_id);
	 	 $query = $this->db 
	 	 				  ->select('title')
	 	 				  ->select('id')
	 	 				  ->from('articles')
	 	 				  ->where('user_id', $user_id)
	 	 				  ->get();
    return $query->result();
    }

    public function add_article($array)
    {
    	return $this->db->insert('articles',$array);
    	//ya auta auxa nita so true
    }

    public function find_article($article_id)
    {
    	$query = $this->db->select(['id','title','body'])
    					->where('id', $article_id)
    					->get('articles');
    	return $query->row();
    }
}
?>