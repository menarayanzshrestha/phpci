<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->model('Model_user');
        $this->load->library('encrypt');
    }

    public function index()
    {
        $this->load->library('form_validation');
        $data = array();
        if (isset($_POST['submit'])) {

            $this->form_validation->set_rules('username', 'Username', 'callback_checkLength|callback_empty_field');
            $this->form_validation->set_rules('password', 'Password', 'min_length[6]|callback_empty_field');
            if ($this->form_validation->run() == FALSE)
            {
                $data['error_message'] = validation_errors();
            } else {
                $data['username'] = $_POST['username'];
                $data['password'] = $this->encrypt->encode($_POST['password']);
                $data['created'] = date('Y-m-d H:i:s');
                $data['gender'] = $_POST['gender'];

                if ($this->Model_user->save($data) == TRUE) {
                    $data['success_message'] = 'Successfully created !';
                }
            }
        }
        $data['users'] = $this->Model_user->getAll();
        $this->load->view('welcome_message', $data);
    }
    public function empty_field($str)
    {
        if ($str == '') {
            $this->form_validation->set_message('empty_field', 'This is field is empty. Please fill it.');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function checkLength($str){
        if(strlen($str)>=6){
            return True;
        }
        else{
            $this->form_validation->set_message('checkLength', 'This is field has less than 6 characters.haha Please fill it.');
            return False;
        }
    }

    public function good()
    {
        echo 'HELLO';
    }

}
?>