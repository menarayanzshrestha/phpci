<?php

class Admin extends CI_Controller{
	
 public function dashboard()
 {
 	$this->load->model('Articlesmodel','articles');

    $articles = $this->articles->articles_list();

     $user_id = $this->session->userdata('user_id');
   
 	$this->load->view('admin/dashboard.php', ['articles'=>$articles]);
 }

 public function add_article()
 {
 	$this->load->view('admin/add_article');
 }

 public function store_article()
 {
	$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');
	if($this->form_validation->run('add_article_rules') ) {
		$post = $this->input->post();
		unset($post['submit']);

		$this->load->model('Articlesmodel','articles');
		if($this->articles->add_article($post))
		{
				$this->session->set_flashdata('feedback','Articles added successfully.');
		}else{
				$this->session->set_flashdata('feedback','Sorry Articles cannot be added.');
			}
		return redirect('admin/dashboard');

 	}else
 	return $this->load->view('admin/add_article');

 }

public function edit_article($article_id)
 {
 	$this->load->model('Articlesmodel','articles');
 	$article = $this->articles->find_article($article_id);
 	$this->load->view('admin/edit_article',['article'=>$article]);
 }

 public function update_article()
 {
 	print_r($this->input->post());
 }

public function delete_article()
 {

 }

 public function __construct()
    {
    parent::__construct();
	if(!$this->session->userdata('user_id'))
	 	{
	 		return redirect('login');
	 	}
    }

}

?>