<?php 

class Login extends CI_Controller {

	public function index()
    {
        if ($this->session->userdata('user_id'))
            return redirect('admin/dashboard');

        $this->load->view('public/admin_login.php');    
    }

    public function admin_login()
    {
    	$this->form_validation->set_rules('Username','Username','required|alpha|trim');
    	$this->form_validation->set_rules('Password','Password','required');
    	$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');

    	if($this->form_validation->run() == TRUE) {
    		//success
            $username = $this->input->post('Username');
            $password = $this->input->post('Password');
         
            $this->load->model('loginmodel');
            $login_id = $this->loginmodel->loginvalid($username, $password );
            if($login_id) {
                
            	$this->session->set_userdata('user_id', $login_id);
            	return redirect('admin/dashboard');
            	
            }else{
            	//fail
                $this->session->set_flashdata('login_failed','Invalid username and password');
                return redirect('login');
            	// echo "pasword donot match";
            }
    		
    	}else {
    		$this->load->view('public/admin_login.php');
    	}
    }

    public function logout()
    {
        $this->session->unset_userdata('user_id');
        return redirect('login');
    }
}
?> 